package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.Car;
import softuni.exam.models.DTOs.CarDto;
import softuni.exam.repository.CarRepository;
import softuni.exam.service.CarService;
import softuni.exam.util.ValidationUtil;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.Optional;

import static softuni.exam.util.Paths.CARS_JSON_PATH;

@Service
public class CarServiceImpl implements CarService {

    private final CarRepository carRepository;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final Gson gson;

    @Autowired
    public CarServiceImpl(CarRepository carRepository, ModelMapper modelMapper, ValidationUtil validationUtil, Gson gson) {
        this.carRepository = carRepository;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
        this.gson = gson;
    }

    @Override
    public boolean areImported() {
        return carRepository.count() > 0;
    }

    @Override
    public String readCarsFileContent() throws IOException {
        return Files.readString(Path.of(CARS_JSON_PATH));
    }

    @Override
    public String importCars() throws IOException {
        StringBuilder sb = new StringBuilder();

        Arrays.stream(gson
                .fromJson(readCarsFileContent(), CarDto[].class))
                .filter(carsDto -> {
                    boolean isValid = validationUtil.isValid(carsDto);

                    sb.append(isValid
                            ? String.format("Successfully imported car - %s - %s" , carsDto.getMake(),carsDto.getModel())
                            : "Invalid car")
                            .append(System.lineSeparator());

                    return isValid;
                })
                .map(carsDto -> modelMapper.map(carsDto, Car.class))
                .forEach(carRepository::save);

        return sb.toString();
    }

    @Override
    public String getCarsOrderByPicturesCountThenByMake() {
        StringBuilder sb = new StringBuilder();

        carRepository
                .findCarsOrderByPicturesCountThenByMakeAnd()
                .stream()
                .forEach(car->{
                    sb
                            .append(String.format("Car make - %s, model - %s\n" +
                                    "\tKilometers - %d\n" +
                                    "\tRegistered on - %s\n" +
                                    "\tNumber of pictures - %d\n" +
                                    ". . . \n",car.getMake(),car.getModel(),car.getKilometers(),car.getRegisteredOn(),car.getPictures().size()));

                });
        return sb.toString().trim();


    }

    @Override
    public  Car findCarById(Long id) {
        Optional<Car> carById = carRepository.getCarById(id);
        if (carById.isEmpty()) {
            return null;
        }
        return carById.get();
    }
}

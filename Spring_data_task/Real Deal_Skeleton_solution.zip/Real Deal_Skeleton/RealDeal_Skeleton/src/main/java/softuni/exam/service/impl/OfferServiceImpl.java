package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.DTOs.OfferImportWrapper;
import softuni.exam.models.Offer;
import softuni.exam.repository.CarRepository;
import softuni.exam.repository.OfferRepository;
import softuni.exam.repository.SellerRepository;
import softuni.exam.service.CarService;
import softuni.exam.service.OfferService;
import softuni.exam.service.SellerService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static softuni.exam.util.Paths.OFFERS_XML_PATH;

@Service
public class OfferServiceImpl implements OfferService {

    private final OfferRepository offerRepository;
    private final CarRepository carRepository;
    private final SellerRepository sellerRepository;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final XmlParser xmlParser;
    private final CarService carService;
    private final SellerService sellerService;

    public OfferServiceImpl(OfferRepository offerRepository, CarRepository carRepository, SellerRepository sellerRepository, ModelMapper modelMapper, ValidationUtil validationUtil, XmlParser xmlParser, CarService carService, SellerService sellerService) {
        this.offerRepository = offerRepository;
        this.carRepository = carRepository;
        this.sellerRepository = sellerRepository;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
        this.xmlParser = xmlParser;
        this.carService = carService;
        this.sellerService = sellerService;
    }


    @Override
    public boolean areImported() {
        return offerRepository.count() > 0;
    }

    @Override
    public String readOffersFileContent() throws IOException {
        return Files.readString(Path.of(OFFERS_XML_PATH));
    }

    @Override
    public String importOffers() throws IOException, JAXBException {
        StringBuilder sb = new StringBuilder();

        OfferImportWrapper offerImportWrapper = xmlParser
                .fromFile(OFFERS_XML_PATH, OfferImportWrapper.class);

        offerImportWrapper.getOffersList()
                .stream()
                .filter(offerDto -> {
                    boolean isValid = validationUtil.isValid(offerDto);

                    // if (agentService.getAgentByName(offerSeedDto.getName().getName()) == null) { ====> if still not exist such agent
                    //   isValid = false;                                                         ====>"If agent with the given name doesn’t already exist in the DB return "Invalid offer"
                    // }

                    // if (cityRepository.findFirstById(forecast.getCity()).isPresent()) {} --> if exists

//                    boolean doesntExist = shopRepository.findShopByName(shopDto.getName())//check if it already exists
//                            .isEmpty();
//                    if (!doesntExist){
//                        isValid = false;
//                    }

                    sb.append(isValid
                            ? String.format("Successfully imported offer %s - %s", offerDto.getAddedOn(),offerDto.getHasGoldStatus())
                            : "Invalid offer")
                            .append(System.lineSeparator());

                    return isValid;
                })
                .map(offerDto -> {
                    Offer offer = modelMapper.map(offerDto, Offer.class);
                    offer.setCar(carService.findCarById(offerDto.getCar())); // to check if it should be like this
                    offer.setSeller(sellerService.findSellerById(offerDto.getSeller()));

                    return offer;
                })
                .forEach(offerRepository::save);

        return sb.toString();
    }
}

package softuni.exam.models.DTOs;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import softuni.exam.models.Enums.Rating;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.validation.constraints.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@XmlRootElement(name = "seller")
@XmlAccessorType(XmlAccessType.FIELD)
public class SellerImport {

    @Size(min=2,max=19)
    @XmlElement(name = "first-name")
    private String firstName;

    @Size(min=2,max=19)
    @XmlElement(name = "last-name")
    private String lastName;


    @Email
    @XmlElement()
    private String email;

    @NotNull
    @XmlElement()
    private String rating;


    @NotNull
    @XmlElement()
    private String town;


}

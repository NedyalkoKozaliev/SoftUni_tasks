package softuni.exam.models.DTOs;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
public class CarDto {

    @Size(min=2,max=19)
    private String make;

    @Size(min=2,max=19)
    private String model;

    @Positive
    private Integer kilometers;


    private String registeredOn;
}

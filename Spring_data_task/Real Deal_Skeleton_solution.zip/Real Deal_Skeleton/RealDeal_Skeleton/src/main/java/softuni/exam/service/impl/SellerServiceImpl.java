package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.Car;
import softuni.exam.models.DTOs.SellerImportWrapper;
import softuni.exam.models.Seller;
import softuni.exam.repository.SellerRepository;
import softuni.exam.service.SellerService;
import softuni.exam.util.ValidationUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

import static softuni.exam.util.Paths.PICTURES_JSON_PATH;
import static softuni.exam.util.Paths.SELLERS_XML_PATH;

@Service
public class SellerServiceImpl implements SellerService {

    private final SellerRepository sellerRepository;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final XmlParser xmlParser;

    public SellerServiceImpl(SellerRepository sellerRepository,
                             ModelMapper modelMapper,
                             ValidationUtil validationUtil, XmlParser xmlParser) {
        this.sellerRepository = sellerRepository;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
        this.xmlParser = xmlParser;
    }

    @Override
    public boolean areImported() {
        return sellerRepository.count() > 0;
    }

    @Override
    public String readSellersFromFile() throws IOException {
        return Files.readString(Path.of(SELLERS_XML_PATH));
    }

    @Override
    public String importSellers() throws IOException, JAXBException {
        StringBuilder sb = new StringBuilder();

        SellerImportWrapper sellersImport = xmlParser
                .fromFile(SELLERS_XML_PATH, SellerImportWrapper.class);

        sellersImport.getSellersList()
                .stream()
                .filter(sellerDto -> {
                    boolean isValid = validationUtil.isValid(sellerDto);

                    // if (agentService.getAgentByName(offerSeedDto.getName().getName()) == null) { ====> if still not exist such agent
                    //   isValid = false;                                                         ====>"If agent with the given name doesn’t already exist in the DB return "Invalid offer"
                    // }

                    // if (cityRepository.findFirstById(forecast.getCity()).isPresent()) {} --> if exists

//                    boolean doesntExist = shopRepository.findShopByName(shopDto.getName())//check if it already exists
//                            .isEmpty();
//                    if (!doesntExist){
//                        isValid = false;
//                    }

                    sb.append(isValid
                            ? String.format("Successfully imported seller %s - %s", sellerDto.getLastName(),sellerDto.getEmail())
                            : "Invalid seller")
                            .append(System.lineSeparator());

                    return isValid;
                })
                .map(sellerDto -> {
                    Seller seller = modelMapper.map(sellerDto, Seller.class);
                                        return seller;
                })
                .forEach(sellerRepository::save);

        return sb.toString();
    }

    @Override
    public Seller findSellerById(Long sellerId) {
        Optional<Seller> sellerById = sellerRepository.getSellerById(sellerId);
        if (sellerById.isEmpty()) {
            return null;
        }
        return sellerById.get();
    }
    }


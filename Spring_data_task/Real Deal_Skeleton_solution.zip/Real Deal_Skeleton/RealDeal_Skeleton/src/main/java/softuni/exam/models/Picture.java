package softuni.exam.models;

//import jakarta.persistence.Column;
//import jakarta.persistence.Entity;
//import jakarta.persistence.ManyToOne;
//import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor

@Entity
@Table(name = "pictures")
public class Picture extends BaseEntity{

    @Size(min=2,max=19)
    @Column(unique = true)
    private String name;


    @Column()
    private LocalDateTime dateAndTime;

@ManyToOne
   private Car car;




//    @OneToMany
//    private Offer offer;
//    •	id – integer number, primary identification field.
//            •	name – a char sequence (between 2 to 20 exclusive). The name of a picture is unique.
//•	dateAndTime – The date and time of a picture.

}

package softuni.exam.models;

//import jakarta.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import softuni.exam.models.Enums.Rating;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Getter
@Setter
@NoArgsConstructor

@Entity
@Table(name = "sellers")
public class Seller extends BaseEntity {


    @Column()
    private String firstName;


    @Column()
    private String lastName;

    @Column(unique = true)
    @Email
    private String email;
    @Enumerated(EnumType.STRING)
    @Column()
    private Rating rating;

    //•	Constraint: The agennullable = false)
    @Column()
    private String town;


//•	id – integer number, primary identification field.
//            •	firstName – a char sequence (between 2 to 20 exclusive).
//            •	lastName – a char sequence (between 2 to 20 exclusive).
//            •	email – an email – (must contains ‘@’ and ‘.’ – dot). The email of a seller is unique.
//•	rating – enumerated value must be one of these GOOD, BAD or UNKNOWN. Cannot be null.
//            •	town – a char sequence – the name of a town. Cannot be null.

}


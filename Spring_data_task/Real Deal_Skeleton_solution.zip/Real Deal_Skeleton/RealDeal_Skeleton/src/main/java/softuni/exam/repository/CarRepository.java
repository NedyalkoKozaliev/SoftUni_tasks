package softuni.exam.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import softuni.exam.models.Car;

import javax.swing.text.html.Option;
import java.util.List;
import java.util.Optional;

//ToDo
@Repository
public interface CarRepository extends JpaRepository<Car, Long> {



    @Query("Select c From Car c ORDER BY size(c.pictures) DESC, c.make")
    List<Car> findCarsOrderByPicturesCountThenByMakeAnd();

    Optional<Car> getCarById(Long id);
}

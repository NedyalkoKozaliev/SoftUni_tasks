package softuni.exam.models;

//import jakarta.persistence.Column;
//import jakarta.persistence.Entity;
//import jakarta.persistence.OneToMany;
//import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;
import java.time.LocalDate;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor

@Entity
@Table(name = "cars")
public class Car extends BaseEntity{


    @Column()
    private String make;


    @Column()
    private String model;


    @Column()
   private Integer kilometers;

    @Column
    private LocalDate registeredOn;

    @OneToMany(mappedBy = "car",fetch = FetchType.EAGER)
    private Set<Picture> pictures;



//    •	id – integer number, primary identification field.
//            •	make – a char sequence (between 2 to 20 exclusive).
//            •	model – a char sequence (between 2 to 20 exclusive).
//            •	kilometers – a number (must be positive).
//            •	registeredOn – a date.
//    The combination of make, model and kilometers makes a car unique.


}

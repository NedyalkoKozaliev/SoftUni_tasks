package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.DTOs.PictureDto;
import softuni.exam.models.Picture;
import softuni.exam.repository.CarRepository;
import softuni.exam.repository.PictureRepository;
import softuni.exam.service.CarService;
import softuni.exam.service.PictureService;
import softuni.exam.util.ValidationUtil;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

import static softuni.exam.util.Paths.PICTURES_JSON_PATH;

@Service
public class PictureServiceImpl implements PictureService {

    private final PictureRepository pictureRepository;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;
    private final Gson gson;
    private final CarRepository carRepository;
    private final CarService carService;

    public PictureServiceImpl(PictureRepository pictureRepository,
                              ModelMapper modelMapper, ValidationUtil validationUtil,
                              Gson gson, CarRepository carRepository, CarService carService) {
        this.pictureRepository = pictureRepository;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
        this.gson = gson;
        this.carRepository = carRepository;
        this.carService = carService;
    }



    @Override
    public boolean areImported() {
        return pictureRepository.count() > 0;
    }

    @Override
    public String readPicturesFromFile() throws IOException {
        return Files.readString(Path.of(PICTURES_JSON_PATH));
    }

    @Override
    public String importPictures() throws IOException {
        StringBuilder sb = new StringBuilder();



        Arrays.stream(gson
                .fromJson(readPicturesFromFile(), PictureDto[].class))
                .filter(picDto -> {
                    boolean isValid = validationUtil.isValid(picDto);
                   // boolean doesntExist = laptopRepository.findLaptopByMacAddress(laptopDto.getMacAddress())//check if it already exists
                  //          .isEmpty();
//                    if (!doesntExist){
//                        isValid = false;
//                    }

                    sb.append(isValid
                            ? String.format("Successfully imported picture %s",picDto.getName())
                            : "Invalid picture")
                            .append(System.lineSeparator());

                    return isValid;
                })
                .map(picDto -> {
                            Picture picture = modelMapper.map(picDto, Picture.class);

                            picture.setCar(carService.findCarById(picDto.getCar()));
                        return  picture;}
                )
                .forEach(pictureRepository::save);

        return sb.toString();



                }
}

package softuni.exam.models;
//
//import jakarta.persistence.Column;
//import jakarta.persistence.Entity;
//import jakarta.persistence.ManyToOne;
//import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.Positive;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor

@Entity
@Table(name = "offers")
public class Offer extends BaseEntity {


    @Column()
    private BigDecimal price;


    @Column()
    private String description;


    @Column()
    private Boolean hasGoldStatus;

    @Column()
    private LocalDateTime addedOn;

    @ManyToOne
    private Car car;

    @ManyToOne
    private Seller seller;

    @ManyToMany
    private Set<Picture> pictures;

}


//    @OneToMany
//    private Picture picture;


//    •	id – integer number, primary identification field.
//            •	price – a number (must be positive number).
//            •	description – a very long text with minimum length 5.
//            •	hasGoldStatus –  can be true or false.
//            •	addedOn – date and time of adding the offer.
//    The combination of description and addedOn makes an offer unique.



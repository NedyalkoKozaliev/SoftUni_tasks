package softuni.exam.models.Enums;

public enum Rating {
    GOOD, BAD, UNKNOWN
}

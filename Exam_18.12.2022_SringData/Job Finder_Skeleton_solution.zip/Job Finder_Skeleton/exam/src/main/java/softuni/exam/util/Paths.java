package softuni.exam.util;

public enum Paths {
    ;

    public static final String COUNTRY_JSON_PATH="src/main/resources/files/json/countries.json";
    public static final String PERSON_JSON_PATH="src/main/resources/files/json/people.json";

    public static final String COMPANY_XML_PATH ="src/main/resources/files/xml/companies.xml";
    public static final String JOB_XML_PATH="src/main/resources/files/xml/jobs.xml";
//     "D:\\java\\Spring_data\\13.12.2022A\\29.03.2020\\Real Deal_Skeleton\\RealDeal_Skeleton\\src\\main\\resources\\files\\json\\cars.json";
//     "D:\\java\\Spring_data\\13.12.2022A\\29.03.2020\\Real Deal_Skeleton\\RealDeal_Skeleton\\src\\main\\resources\\files\\json\\pictures.json";
//    "D:\\java\\Spring_data\\13.12.2022A\\29.03.2020\\Real Deal_Skeleton\\RealDeal_Skeleton\\src\\main\\resources\\files\\xml\\sellers.xml";
//    public static final String OFFERS_XML_PATH="D:\\java\\Spring_data\\13.12.2022A\\29.03.2020\\Real Deal_Skeleton\\RealDeal_Skeleton\\src\\main\\resources\\files\\xml\\offers.xml";

//    public static final Path PASSENGER_JSON_PATH = Path.of("src\main\resources\files\json\passengers.json");
//
//    public static final Path PLANES_XML_PATH = Path.of("src\main\resources\files\xml\planes.xml");
//    public static final Path TICKETS_XML_PATH = Path.of("src\main\resources\files\xml\tickets.xml");
}


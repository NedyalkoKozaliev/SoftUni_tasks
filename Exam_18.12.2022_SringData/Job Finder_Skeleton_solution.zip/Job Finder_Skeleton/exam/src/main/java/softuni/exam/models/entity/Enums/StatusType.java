package softuni.exam.models.entity.Enums;

public enum StatusType {
    unemployed, employed, freelancer
}
